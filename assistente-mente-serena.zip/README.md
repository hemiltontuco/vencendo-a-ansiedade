# Assistente de Regulação Mente Serena

Um mini web app desenvolvido em HTML, CSS e JavaScript puro para identificar o estado emocional atual do usuário e fornecer direcionamentos personalizados.

## 🎯 Objetivo

Identificar o estado emocional através de 6 perguntas com escala de 0 a 3 e exibir:
- Estado predominante
- Direcionamento detalhado com materiais, técnicas e áudios
- Botão de compra para o Protocolo Mente Serena

## 🚀 Como usar

1. **Abrir o app**: Abra o arquivo `index.html` em qualquer navegador
2. **Iniciar avaliação**: Clique em "Iniciar Avaliação"
3. **Responder perguntas**: Complete as 6 perguntas sobre seu estado atual
4. **Ver resultado**: Receba direcionamentos personalizados baseados nas suas respostas

## 📱 Funcionalidades

- **Interface responsiva**: Funciona perfeitamente em desktop e mobile
- **Navegação intuitiva**: Botões de anterior/próximo e atalhos de teclado (setas)
- **Persistência local**: Salva automaticamente o progresso no localStorage
- **Acessibilidade**: Design focado em usabilidade e acessibilidade
- **Animações suaves**: Transições elegantes entre telas e perguntas

## 🧠 Lógica de Avaliação

### Estados Avaliados:
- **Corpo em Alerta**: Sintomas físicos (tensão, falta de ar)
- **Mente Acelerada**: Pensamentos repetitivos e acelerados
- **Medo do Medo/Evitação**: Tendência a evitar situações
- **Sensação de Ameaça**: Interpretação de risco ou perigo
- **Sobrecarga Mental**: Exaustão cognitiva e excesso de estímulos

### Cálculo de Pontuação:
- Perguntas 1-5: Cada resposta vale de 0 a 3 pontos
- Pergunta 6: Adiciona +2 pontos ao estado escolhido
- Estado com maior pontuação = predominante
- Em caso de empate, pergunta 6 é critério de desempate

## 🎨 Design

- **Cores**: Paleta azul claro e branco para transmitir calma
- **Tipografia**: Sans-serif moderna e legível
- **Layout**: Centralizado com cards arredondados
- **Responsividade**: Mobile-first design

## 🛠️ Estrutura Técnica

### Arquivos:
- `index.html`: Estrutura HTML com todas as telas
- `style.css`: Estilos CSS com design responsivo
- `script.js`: Lógica JavaScript pura (sem frameworks)

### Principais Funcionalidades JavaScript:
- Sistema de navegação entre telas
- Cálculo automático de pontuação
- Persistência em localStorage
- Validação de formulário
- Geração dinâmica de resultados

## 🔧 Customização

### Modificar Direcionamentos:
Edite a constante `DIRECIONAMENTOS` em `script.js`:

```javascript
const DIRECIONAMENTOS = {
    corpo: {
        titulo: "Corpo em Alerta",
        descricao: "Descrição do estado...",
        principal: ["Material 1", "Material 2"],
        complementar: ["Material complementar"],
        audios: ["Audio 1", "Audio 2"]
    }
    // ... outros estados
};
```

### Modificar Perguntas:
Edite as perguntas diretamente no HTML em `index.html` nas divs com classe `pergunta`.

### Personalizar Design:
Modifique as variáveis CSS em `style.css`:
- Cores: Altere os gradientes e cores dos botões
- Tipografia: Modifique font-family e tamanhos
- Layout: Ajuste padding, margins e border-radius

## 📊 Dados e Privacidade

- **Armazenamento local**: Os dados são salvos apenas no navegador do usuário
- **Sem coleta externa**: Nenhum dado é enviado para servidores externos
- **Limpeza automática**: Dados são removidos após 24 horas de inatividade
- **Privacidade total**: O usuário tem controle total sobre seus dados

## 🚀 Deployment

### Para colocar online:

1. **Hospedagem estática**: 
   - Upload dos arquivos para qualquer serviço (Netlify, Vercel, GitHub Pages)
   - Todos os arquivos devem estar na raiz

2. **Servidor local**:
   - Abra `index.html` diretamente no navegador
   - Ou use um servidor local (Live Server, Python SimpleHTTPServer, etc.)

## 🔮 Expansões Futuras

O código está preparado para:
- **Histórico de avaliações**: Salvar múltiplas avaliações
- **Exportação de dados**: Gerar relatórios em PDF
- **Integração com APIs**: Enviar dados para análise externa
- **Notificações**: Lembretes para reavaliação
- **Mais estados**: Adicionar novos tipos de estado emocional

## 🐛 Debugging

Para debuggar, use o console do navegador:

```javascript
// Ver estado atual
menteSerenaDebug.logEstado();

// Ver respostas
menteSerenaDebug.respostas();

// Limpar localStorage
menteSerenaDebug.limparStorage();
```

## 📄 Licença

Este projeto foi desenvolvido como ferramenta complementar ao Protocolo Mente Serena. Todos os direitos reservados.

---

**Desenvolvido com 💙 para ajudar pessoas com ansiedade a encontrarem direcionamento e regulação emocional.**
